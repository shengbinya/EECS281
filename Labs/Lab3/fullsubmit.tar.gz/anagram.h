/*
 * anagram.h
 * Univeristy of Michigan, Ann Arbor
 * EECS 281 Lab 3 Written.
 * DO NOT SUBMIT TO GRADESCOPE.
 * If submitted, this file will be ignored.
 */
#ifndef ANAGRAM_H
#define ANAGRAM_H

#include <string>

bool isAnagram(const std::string &s1, const std::string &s2);

#endif
