// Project Identifier: 19034C8F3B1196BF8E0C6E1C0F973D2FD550B88F

#include <iostream>
#include <vector>
#include <getopt.h>
#include <deque>
#include <queue>
#include "P2random.h"
#include <set>
#include <iomanip>

using namespace std;

struct tile {
public:

    tile() : rubble{ 0 }, row{ 0 }, col{ 0 }{}

    tile(int rubble_in, unsigned row_in, unsigned int col_in) :
        rubble{ rubble_in }, row{ row_in }, col{ col_in }{}

    int rubble;
    unsigned int row;
    unsigned int col;
    bool discovered = false;

};

struct tileComp {
    bool operator()(const tile& a, const tile& b) {
        if (a.rubble > b.rubble)
            return true;
        else if (a.rubble < b.rubble)
            return false;
        else if (a.col > b.col)
            return true;
        else if (a.col < b.col)
            return false;
        else if (a.row > b.row)
            return true;
        else
            return false;
    }
};

struct tileCompOp {
    bool operator()(const tile& b, const tile& a) {
        if (a.rubble > b.rubble)
            return true;
        else if (a.rubble < b.rubble)
            return false;
        else if (a.col > b.col)
            return true;
        else if (a.col < b.col)
            return false;
        else if (a.row > b.col)
            return true;
        else
            return false;
    }
};

class mine {
public:

    //Grabs options from command line
    void get_options(int argc, char** argv);

    //Reads in input from file
    void readMine();

    //Write out mine in command line
    void writeMine();

    void breakout();

    void discover(const tile&);

    bool edge(const tile&);

    void setEdge(int row, int col);

    void insert(int);

    void printMedian();

    void printStats();

    void blowUp(const tile& current);

private:

    //Underlying Data Structures
    vector<vector<tile>> gridMine;
    priority_queue<tile, vector<tile>, tileComp> primaryQueue;
    priority_queue<tile, vector<tile>, tileComp> TNTQueue;
    vector<int> median;
    vector<tile> discard;

    //Initial Variables
    pair<unsigned int, unsigned int> start = { 0,0 };
    unsigned int totalRubble = 0;
    unsigned int totalTiles = 0;

    //Command Line Args
    int firstCleared = -1;
    bool m = false;
    bool v = false;
    tile finalEdge {-3, 0, 0};
    int triggered = false;
    

};

//Definitions:
//If something is "cleared" the rubble value is set to 0
//If something is "discovered" the discovered variable is set to true
//If something is "investigated" the discovered variable is true and the rubble value is 0

/* Helper Functions*/

void mine::insert(int val) {
    auto it = lower_bound(median.begin(), median.end(), val);
    median.insert(it, val);
}

void mine::printMedian() {
    cout << "Median difficulty of clearing rubble is: ";
    cout << std::fixed << std::setprecision(2);
    if (median.size() % 2 == 0)
        if (median.size() != 1) {
            double step = (median[median.size() / 2] + median[median.size() / 2 - 1]);
            step = step / 2;
            cout << step << "\n";
        }
        else
            cout << double(median.at(0)) << "\n";
    else
        cout << double(median[median.size() / 2]) << "\n";
}

void mine::writeMine() {
    for (unsigned int i = 0; i < gridMine.size(); ++i) {
        for (unsigned int j = 0; j < gridMine.size(); ++j) {
            cout << gridMine[i][j].rubble << " ";
        }
        cout << "\n";
    }
}

void mine::printStats() {

    cout << "First tiles cleared:\n";
    for (int i = 0; i < firstCleared && i < int(discard.size()); i++) {
        if (discard[i].rubble != -1)
            cout << discard[i].rubble << " at [" << discard[i].row << "," << discard[i].col << "]\n";
        else
            cout << "TNT at [" << discard[i].row << "," << discard[i].col << "]\n";
    }

    cout << "Last tiles cleared:\n";
    for (int i = int(discard.size()) - 1; i > int(discard.size()) - firstCleared && i > -1; --i) {
        if (discard[i].rubble != -1)
            cout << discard[i].rubble << " at [" << discard[i].row << "," << discard[i].col << "]\n";
        else
            cout << "TNT at [" << discard[i].row << "," << discard[i].col << "]\n";
    }

    priority_queue<tile, vector<tile>, tileComp> statsQueue(discard.begin(), discard.end());
    cout << "Easiest tiles cleared:\n";
    for (int i = 0; i < firstCleared && i < int(discard.size()); i++) {
        if (statsQueue.top().rubble != -1)
            cout << statsQueue.top().rubble << " at [" << statsQueue.top().row << "," << statsQueue.top().col << "]\n";
        else
            cout << "TNT at [" << statsQueue.top().row << "," << statsQueue.top().col << "]\n";
        statsQueue.pop();
    }

    priority_queue<tile, vector<tile>, tileCompOp> statsQueueBack(discard.begin(), discard.end());
    cout << "Hardest tiles cleared:\n";
    for (int i = 0; i < firstCleared && i < int(discard.size()); i++) {
        if (statsQueueBack.top().rubble != -1)
            cout << statsQueueBack.top().rubble << " at [" << statsQueueBack.top().row << "," << statsQueueBack.top().col << "]\n";
        else
            cout << "TNT at [" << statsQueueBack.top().row << "," << statsQueueBack.top().col << "]\n";
        statsQueueBack.pop();
    }


}

bool mine::edge(const tile& current) {
    if (current.col != 0 && current.row != 0 &&
        current.col != gridMine.size() && current.row != gridMine.size())
        return false;
    return true;
}

void mine::setEdge(int row, int col) {
    if (finalEdge.rubble != -3) return;
    finalEdge.rubble = -4;
    finalEdge.row = row;
    finalEdge.col = col;
    finalEdge.discovered = true;
}

void mine::blowUp(const tile& current) {
    unsigned int row = current.row;
    unsigned int col = current.col;

    //If not in top row
    if (row != 0) {
        if (gridMine[row - 1][col].rubble != 0) {
            TNTQueue.push(gridMine[row - 1][col]);
            //Clear here to indicate that it has already been blown up
            gridMine[row - 1][col].rubble = 0;
            gridMine[row - 1][col].discovered = true;
        }
    }
    else
        setEdge(row, col);

    //If not in bottom row
    if (row != gridMine.size() - 1 ) {
        if (gridMine[row + 1][col].rubble != 0) {
            TNTQueue.push(gridMine[row + 1][col]);
            gridMine[row + 1][col].rubble = 0;
            gridMine[row + 1][col].discovered = true;
        }
    }
    else
        setEdge(row, col);

    //If not on left edge
    if (col != 0) {
        if (gridMine[row][col - 1].rubble != 0) {
            TNTQueue.push(gridMine[row][col - 1]);
            gridMine[row][col - 1].rubble = 0;
            gridMine[row][col - 1].discovered = true;
        }
    }
    else
        setEdge(row, col);

    //If not on bottom edge
    if (col != gridMine.size() - 1){
        if (gridMine[row][col + 1].rubble != 0) {
            TNTQueue.push(gridMine[row][col + 1]);
            gridMine[row][col + 1].rubble = 0;
            gridMine[row][col + 1].discovered = true;
        }
    }
    else
        setEdge(row, col);
}

void mine::discover(const tile& current) {
    unsigned int row = current.row;
    unsigned int col = current.col;

    //If not on upper edge
    if (row != 0) {
        //If not already discovered
        if (!gridMine[current.row - 1][current.col].discovered) {
            primaryQueue.push(gridMine[current.row - 1][current.col]);
            gridMine[current.row - 1][current.col].discovered = true;
        }
            
    }
    else
        setEdge(row, col);

    //If not on lower edge
    if (row != gridMine.size() - 1) {
        //If not already discovered
        if (!gridMine[current.row + 1][current.col].discovered) {
            primaryQueue.push(gridMine[current.row + 1][current.col]);
            gridMine[current.row + 1][current.col].discovered = true;
        }
            
    }
    else
        setEdge(row, col);

    //If not on left edge
    if (col != 0) {
        //If not already discovered
        if (!gridMine[row][col - 1].discovered) {
            primaryQueue.push(gridMine[row][col - 1]);
            gridMine[row][col - 1].discovered = true;
        }
            
    }
    else
        setEdge(row, col);

    //If not on right edge
    if (col != gridMine.size() - 1) {
        //If not already discovered
        if (!gridMine[row][col + 1].discovered) {
            primaryQueue.push(gridMine[row][col + 1]);
            gridMine[row][col + 1].discovered = true;
        }   
    }
    else
        setEdge(row, col);

}

/* Main Functions */
void mine::get_options(int argc, char** argv) {
    int option_index = 0, option = 0;

    // Don't display getopt error messages about options
    opterr = false;

    // use getopt to find command line options
    struct option longOpts[] = { { "stats", required_argument, nullptr, 's' },
                                { "median", no_argument, nullptr, 'm' },
                                { "verbose", no_argument, nullptr, 'v' },
                                { "help", no_argument, nullptr, 'h'},
                                { nullptr, 0, nullptr, '\0' } };

    while ((option = getopt_long(argc, argv, "s:mvh", longOpts, &option_index)) != -1) {
        switch (option) {
        case 's':
            firstCleared = atoi(optarg);
            break;

        case 'm':
            m = true;
            break;

        case 'v':
            v = true;
            break;

        case 'h':
           cout << "This program reads in a mine from a file.\n"
                << "It finds the easiest clear path through the mine\n"
                << "and can generate output to indicate this path\n"
                << "according to the provided arguemnts."
                << "Usage: \'./letter\n\t[--stack | -s]\n"
                << "\t[--stats | -s]\n"
                << "\t[--median | -m]\n"
                << "\t[--verbose | -v]\n"
                << "\t[--length | -l]\n"
                << "\t[--help | -h]\n"
                << "\t<Mine File>\'" << std::endl;
            exit(1);
        }
    }
}

void mine::readMine() {
    //Read in common variables
    string mode = "";
    string in = "";
    string dump = "";
    
    cin >> mode;
    //Check if mode is correct
    if (mode != "R" && mode != "M") {
        cout << "Invalid input mode\n";
        exit(1);
    }

    cin >> dump;
    cin >> in;
    //Read in size
    unsigned int size = stoi(in);
    gridMine.resize(stoi(in), vector<tile>(stoi(in)));
    cin >> dump;
    cin >> in;

    start.first = stoi(in);
    //Check if start point is out of range
    if (start.first >= gridMine.size()) {
        cout << "Invalid starting row\n";
        exit(1);
    }

    cin >> in;
    start.second = stoi(in);
    if (start.second > gridMine.size()) {
        cout << "Invalid starting column\n";
        exit(1);
    }

    stringstream ss;
    if (mode == "R") {
        //Read in specifics
        cin >> dump;
        cin >> in;
        int seed = stoi(in);
        cin >> dump;
        cin >> in;
        unsigned int max_rubble = stoi(in);
        cin >> dump;
        cin >> in;
        unsigned int tnt_chance = stoi(in);
        P2random::PR_init(ss, size, seed, max_rubble, tnt_chance);
    }

    istream& inputStream = (mode == "M") ? cin : ss;

    string intermediate;

    for (unsigned int i = 0; i < gridMine.size(); ++i) {
        for (unsigned int j = 0; j < gridMine.size(); ++j) {        
            inputStream >> intermediate;
            gridMine[i][j].rubble = stoi(intermediate);
            gridMine[i][j].row = i;
            gridMine[i][j].col = j;
        }
    }

}

void mine::breakout() {
    
    //Initialize Primary Queue
    tile investigated (gridMine[start.first][start.second].rubble, start.first, start.second);
    investigated.discovered = true;
    primaryQueue.push(investigated);

    //Loop through primary queue discovering and investigating tiles
    while (finalEdge.rubble == -3) {

        //Grab top of primary queue and investigate it
        investigated = primaryQueue.top();
        primaryQueue.pop();
        
            //If not TNT the miner investigates
            if (gridMine[investigated.row][investigated.col].rubble != -1) {
               
                //If the actual tile is not equal to 0 we don't want to output stuff
                //We do want to discover around the tile
                if (gridMine[investigated.row][investigated.col].rubble != 0) {
                    
                    //Clear the actual tile
                    gridMine[investigated.row][investigated.col].rubble = 0;

                    //Statistics Updates
                    if (investigated.rubble != 0) {
                        if (v) {
                            std::cout << "Cleared: " << investigated.rubble << " at [" << investigated.row << "," << investigated.col << "]\n";
                        }

                        totalTiles++;
                        totalRubble += investigated.rubble;

                    }
                }

                //Discover tiles around the cleared tile
                discover(investigated);
       
            }

            //If TNT
            else {

                //Initialize TNT Queue
                TNTQueue.push(investigated);
                tile currentTNT;

                //Fire up TNT While loop
                while (!TNTQueue.empty()) {

                    //Add top of queue to current TNT
                    currentTNT = TNTQueue.top();
                    TNTQueue.pop();

                    //If TNT
                    if (currentTNT.rubble == -1) {

                        //Clear the TNT
                        gridMine[currentTNT.row][currentTNT.col].rubble = 0;
                        if (v)
                            std::cout << "TNT explosion at [" << currentTNT.row << "," << currentTNT.col << "]!\n";

                        //Add stuff around TNT to TNTQueue
                        blowUp(currentTNT);

                    }

                    //If not TNT clear and discover
                    else {

                        //Statistics Updates
                        if (currentTNT.rubble != 0) {
                            if (v)
                                std::cout << "Cleared by TNT: " << currentTNT.rubble << " at [" << currentTNT.row << "," << currentTNT.col << "]\n";
                            totalTiles++;
                            totalRubble += currentTNT.rubble;
                        }

                        //Add Discovered TNT to queue to be investigated
                        primaryQueue.push(gridMine[currentTNT.row][currentTNT.col]);

                    }
                }

            }

    }

    std::cout << "Cleared " << totalTiles << " tiles containing " << totalRubble << " rubble and escaped.\n";
}


int main(int argc, char** argv) {
    std::cout << std::fixed << std::setprecision(2);
	mine jellystone;
	jellystone.get_options(argc, argv);
    jellystone.readMine();
    //jellystone.writeMine();
    jellystone.breakout();
}


/*
//Initialize queue
primaryQueue.push(layout[start.first][start.second]);
tile current = primaryQueue.top();
finalEdge.rubble = -3;

//Loop through queue until edge is reached
while (finalEdge.rubble == -3) {
    current = primaryQueue.top();

    //Check if TNT
    if (current.rubble == -1) {

        //Check if already been exploded
        if (layout[current.row][current.col].rubble == 0)
            primaryQueue.pop();

        else {
            tile top = current;
            TNTQueue.push(top);
            primaryQueue.pop();

            //While TNT Queue is not Empty
            while (!TNTQueue.empty()) {
                top = TNTQueue.top();

                //Check if TNT
                if (top.rubble == -1) {
                    if (v)
                        std::cout << "TNT explosion at [" << top.row << "," << top.col << "]!\n";
                    if (firstCleared != -1)
                        discard.push_back(top);
                    TNTQueue.pop();
                    TNTClear(top);
                    layout[top.row][top.col].rubble = 0;

                }

                //If not TNT Surroundings to Main Queue
                else {
                    if (v) {
                        if (top.rubble != 0) {
                            std::cout << "Cleared by TNT: " << top.rubble << " at [" << top.row << "," << top.col << "]\n";
                        }
                    }
                    if (m) {
                        insert(top.rubble);
                        printMedian();
                    }
                    if (firstCleared != -1)
                        discard.push_back(top);
                    if (top.rubble != 0) {
                        ++totalTiles;
                        totalRubble += top.rubble;
                    }
                    TNTQueue.pop();
                    discover(top);

                }

            }

        }
    }

    //If not TNT then just clear it
    else {
        if (v)
            if (layout[current.row][current.col].rubble != 0)
                std::cout << "Cleared: " << current.rubble << " at [" << current.row << "," << current.col << "]\n";
        if (m) {
            insert(current.rubble);
            printMedian();
        }
        if (firstCleared != -1)
            discard.push_back(current);
        primaryQueue.pop();
        discover(current);
        if (layout[current.row][current.col].rubble != 0) {
            ++totalTiles;
            totalRubble += layout[current.row][current.col].rubble;
        }
        layout[current.row][current.col].rubble = 0;
    }

    if (finalEdge.rubble != -3 && primaryQueue.top().rubble == -1 && !triggered) {
        finalEdge.rubble = -3;
        triggered = true;
    }


}


cout << "Cleared " << totalTiles << " tiles containing " << totalRubble << " rubble and escaped.\n";
if (firstCleared != -1)
printStats();
*/